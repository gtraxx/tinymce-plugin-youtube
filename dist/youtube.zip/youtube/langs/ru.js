tinymce.addI18n('ru',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Вставить видео YouTube",
	'Youtube URL'	    : 'Ссылка',
	'Youtube ID'        : 'http://youtu.be/xxxxxxxx или http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			    : 'Ширина',
	'height'		    : 'Высота',
	'autoplay'		    : 'Автозапуск',
	'Related video'     : 'Похожие видео',
	'HD video'          : 'В формате HD',
    'cancel'            : 'отменить',
    'Insert'            : 'Вставить'
});