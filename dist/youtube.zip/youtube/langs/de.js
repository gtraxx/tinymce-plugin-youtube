tinymce.addI18n('de',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Einfügen von YouTube-Videos",
	'Youtube URL'	    : 'Youtube-Link',
	'Youtube ID'        : 'http://youtu.be/xxxxxxxx  oder http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			    : 'Breite',
	'height'		    : 'Hoehe',
	'autoplay'		    : 'Automatische Wiedergabe?',
	'Related video'     : 'Verwandte Videos anzeigen?',
	'HD video'          : 'In HD abspielen?',
	'cancel'            : 'Stornieren',
    'Insert'            : 'Einfügen'
});