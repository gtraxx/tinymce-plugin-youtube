tinymce.addI18n('en',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Insert a YouTube Video",
	'Youtube URL'	    : 'Link Sharing',
	'Youtube ID'        : 'http://youtu.be/xxxxxxxx or http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			    : 'Width',
	'height'		    : 'Height',
	'autoplay'		    : 'Autoplay',
	'Related video'     : 'Related video',
	'HD video'          : 'Watch in HD',
	'cancel'            : 'Cancel',
    'Insert'            : 'Insert'
});