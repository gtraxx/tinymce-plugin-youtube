tinymce.addI18n('en',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Insert a YouTube Video",
	'Youtube URL'	    : 'Link Sharing',
	'Youtube ID'        : 'Link format for sharing : http://youtu.be/xxxxxxxx or http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			    : 'Width',
	'height'		    : 'Height',
	'autoplay'		    : 'Autoplay',
	'Related video'     : 'Related video',
	'HD video'          : 'Watch in HD',
    'html5'             : 'HTML5',
    'Insert'            : 'Insert'
});