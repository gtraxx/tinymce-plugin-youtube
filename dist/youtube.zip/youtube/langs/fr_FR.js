tinymce.addI18n('fr',{
	'YouTube Title' : "Insertion d'une vidéo youtube",
	'Youtube URL'	: 'URL YouTube',
	'Youtube ID'    : 'Format du lien de partage : http://youtu.be/xxxxxxxx ou http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			: 'Largeur',
	'height'		: 'Hauteur',
	'autoplay'		: 'Autoplay',
	'Related video' : 'Vidéos similaires',
	'HD video'      : 'Visionner en HD'
});