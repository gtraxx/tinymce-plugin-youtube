tinymce.addI18n('lt', {
    'YouTube Tooltip' : "YouTube",
    'YouTube Title' : "Įterpti YouTube Video",
    'Youtube URL' : 'Nuoroda',
    'Youtube ID' : 'http://youtu.be/xxxxxxxx arba http://www.youtube.com/watch?v=xxxxxxxx',
    'width' : 'Plotis',
    'height' : 'Aukštis',
    'autoplay' : 'Autoplay',
    'Related video' : 'Susijęs video',
    'HD video' : 'HD kokybė',
    'cancel' : 'Atšaukti',
    'Insert' : 'Įterpti'
});