tinymce.addI18n('pl',{
	'YouTube Title' : "Wstaw film z YouTube",
	'Youtube URL'	: 'Adres',
	'Youtube ID'    : 'Format adresu: http://youtu.be/xxxxxxxx lub http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			: 'Szeroko\u015B\u0107',
	'height'		: 'Wysoko\u015B\u0107',
	'autoplay'		: 'Automatyczne odtwarzanie',
	'Related video' : 'Pokazuj sugerowane filmy',
	'HD video'      : 'Odtwarzaj w HD'
});