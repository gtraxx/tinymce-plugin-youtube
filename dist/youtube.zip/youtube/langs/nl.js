tinymce.addI18n('nl',{
	'YouTube Title' : "YouTube-video invoegen",
	'Youtube URL'	: 'Video-link',
	'Youtube ID'    : 'Video-links die worden geaccepteerd: http://youtu.be/xxxxxxxx of http://www.youtube.com/watch?v=xxxxxxxx',
	'width'		: 'Breedte',
	'height'	: 'Hoogte',
	'autoplay'	: 'Automatisch afspelen',
	'Related video' : 'Toon gerelateerde videos',
	'HD video'      : 'Toon in HD-resolutie'
});
