tinymce.addI18n('hu', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "Youtube videó beillesztése",
    'Youtube URL'       : 'Link megosztása',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx vagy http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : 'Szélesség',
    'height'            : 'Magasság',
    'autoplay'          : 'Automatikus lejátszás',
    'Related video'     : 'Kapcsolód videó',
    'HD video'          : 'HD lejátszás',
    'cancel'            : 'Megszünteti',
    'Insert'            : 'Beillesztése'
});